---
type: routing-note
agent: Orion
role: UAP Intelligence Agent
date_created: 2026-05-31
date_updated: 2026-06-01
---

# Orion: Routing and Coordination

## When Larry Dispatches Orion

Orion handles UAP-related intelligence, defensive architecture analysis, whistleblower evaluation, disclosure tracking, and classification law analysis.

## Cross-Agent Routing

| Domain | Primary Agent | Secondary Agent |
|--------|---------------|-----------------|
| Classification law (US) | **Cipher** | Lex |
| Nuclear/energy channels | Nova | — |
| Legal/regulatory (non-US) | Lex | — |
| Research assistance | Pax | — |
| Blockchain tracking | Chain | — |
| Economic modeling | Atlas | — |
| Federated custody (Fedi) | TBD | — |

## Routing Updates

| Date | Change |
|------|--------|
| 2026-06-01 | Classification law routing changed from Lex to Cipher (new specialist) |
| 2026-05-31 | Initial routing established |

## Related Agent Contracts

- [[../Cipher - U.S. Classification and National Security Law Agent/AGENTS.md]]
- [[../Lex - Legal and Regulatory Agent/AGENTS.md]]
- [[../Nova - Nuclear and Energy Systems Agent/AGENTS.md]]
- [[../Pax - Researcher/AGENTS.md]]
- [[../Chain - Blockchain Agent/AGENTS.md]]

---

*La misma pauta, cada escala, para siempre.*
